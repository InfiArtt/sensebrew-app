import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'recipe.dart';

class RecipeRepository extends ChangeNotifier {
  List<Recipe> _recipes = [];
  bool _isLoaded = false;

  List<Recipe> get recipes => _recipes;
  bool get isLoaded => _isLoaded;

  Future<void> loadRecipes() async {
    final prefs = await SharedPreferences.getInstance();
    final String? recipesJson = prefs.getString('saved_recipes');

    if (recipesJson == null || recipesJson.isEmpty) {
      // First time launch: copy default database
      _recipes = List.from(recipeDatabase); // recipeDatabase is from recipe.dart
      await saveRecipes();
    } else {
      try {
        final List<dynamic> decodedList = jsonDecode(recipesJson);
        _recipes = decodedList.map((item) => Recipe.fromJson(item as Map<String, dynamic>)).toList();
      } catch (e) {
        print("Error loading recipes: $e");
        _recipes = List.from(recipeDatabase);
      }
    }
    _isLoaded = true;
    notifyListeners();
  }

  Future<void> saveRecipes() async {
    final prefs = await SharedPreferences.getInstance();
    final String encodedList = jsonEncode(_recipes.map((r) => r.toJson()).toList());
    await prefs.setString('saved_recipes', encodedList);
    notifyListeners();
  }

  Future<void> addRecipe(Recipe recipe) async {
    _recipes.insert(0, recipe);
    await saveRecipes();
  }

  Future<void> updateRecipe(Recipe updatedRecipe) async {
    final index = _recipes.indexWhere((r) => r.id == updatedRecipe.id);
    if (index != -1) {
      _recipes[index] = updatedRecipe;
      await saveRecipes();
    }
  }

  Future<void> deleteRecipe(String id) async {
    _recipes.removeWhere((r) => r.id == id);
    await saveRecipes();
  }

  Future<void> restoreDefaults() async {
    // Add default recipes that are missing, or just overwrite all?
    // Let's just append the default recipes if they don't exist by name.
    bool changed = false;
    for (var defaultRecipe in recipeDatabase) {
      if (!_recipes.any((r) => r.name == defaultRecipe.name)) {
        _recipes.add(defaultRecipe);
        changed = true;
      }
    }
    if (changed) {
      await saveRecipes();
    }
  }

  List<Recipe> getRecipesByMethod(BrewMethod method) {
    return _recipes.where((r) => r.method == method).toList();
  }
}
