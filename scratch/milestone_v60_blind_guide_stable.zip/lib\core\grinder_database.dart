import 'app_strings.dart';
class GrinderModel {
  final String id;
  final String name;
  final bool isManual;
  final String Function(int microns) getSetting;

  const GrinderModel({
    required this.id,
    required this.name,
    required this.isManual,
    required this.getSetting,
  });
}

// Grind size targets in microns (approximate)
// Espresso: 300 - 500
// Aeropress / Moka: 500 - 700
// V60 / Pour Over: 700 - 1000
// French Press: 1000 - 1300

final List<GrinderModel> grinderDatabase = [
  // Manual Grinders
  GrinderModel(
    id: 'timemore_c2',
    name: 'Timemore C2 / C3',
    isManual: true,
    getSetting: (microns) {
      if (microns < 500) return '8 - 10 klik';
      if (microns < 700) return '11 - 14 klik';
      if (microns < 1000) return '15 - 18 klik';
      return '20 - 24 klik';
    },
  ),
  GrinderModel(
    id: 'comandante_c40',
    name: 'Comandante C40',
    isManual: true,
    getSetting: (microns) {
      if (microns < 500) return '8 - 12 klik';
      if (microns < 700) return '13 - 18 klik';
      if (microns < 1000) return '20 - 25 klik';
      return '28 - 32 klik';
    },
  ),
  GrinderModel(
    id: 'kingrinder_k6',
    name: 'Kingrinder K6',
    isManual: true,
    getSetting: (microns) {
      if (microns < 500) return '35 - 50 klik';
      if (microns < 700) return '60 - 80 klik';
      if (microns < 1000) return '85 - 110 klik';
      return '115 - 130 klik';
    },
  ),
  GrinderModel(
    id: '1zpresso_jxpro',
    name: '1Zpresso JX-Pro',
    isManual: true,
    getSetting: (microns) {
      if (microns < 500) return '1.2 - 1.6 (Putaran.Angka)';
      if (microns < 700) return '2.0 - 2.5 (Putaran.Angka)';
      if (microns < 1000) return '3.0 - 3.5 (Putaran.Angka)';
      return '4.0 - 4.5 (Putaran.Angka)';
    },
  ),
  GrinderModel(
    id: '1zpresso_kultra',
    name: '1Zpresso K-Ultra',
    isManual: true,
    getSetting: (microns) {
      if (microns < 500) return '3 - 4.5 angka';
      if (microns < 700) return '5 - 6.5 angka';
      if (microns < 1000) return '7 - 8.5 angka';
      return '9 - 10 angka';
    },
  ),
  GrinderModel(
    id: 'vesper_vs3_fold',
    name: 'Vesper VS3 Fold',
    isManual: true,
    getSetting: (microns) {
      // VS3 Fold has very fine threads, up to 110+ clicks
      if (microns < 500) return '15 - 30 klik';
      if (microns < 700) return '35 - 50 klik';
      if (microns < 1000) return '55 - 75 klik';
      return '80 - 110 klik';
    },
  ),
  GrinderModel(
    id: 'vesper_lens',
    name: 'Vesper Lens',
    isManual: true,
    getSetting: (microns) {
      // Vesper Lens maximum is around 54 clicks
      if (microns < 500) return '12 - 16 klik';
      if (microns < 700) return '18 - 25 klik';
      if (microns < 1000) return '28 - 38 klik';
      return '42 - 54 klik';
    },
  ),
  GrinderModel(
    id: 'kinu_m47',
    name: 'Kinu M47',
    isManual: true,
    getSetting: (microns) {
      if (microns < 500) return '0.8 - 1.5 putaran';
      if (microns < 700) return '2.0 - 2.8 putaran';
      if (microns < 1000) return '3.0 - 4.0 putaran';
      return '4.5 - 5.5 putaran';
    },
  ),
  GrinderModel(
    id: 'hario_skerton',
    name: 'Hario Skerton Pro',
    isManual: true,
    getSetting: (microns) {
      if (microns < 500) return '2 - 3 klik';
      if (microns < 700) return '4 - 6 klik';
      if (microns < 1000) return '8 - 10 klik';
      return '12 - 14 klik';
    },
  ),
  GrinderModel(
    id: 'porlex_mini',
    name: 'Porlex Mini',
    isManual: true,
    getSetting: (microns) {
      if (microns < 500) return '3 - 5 klik';
      if (microns < 700) return '6 - 8 klik';
      if (microns < 1000) return '9 - 11 klik';
      return '13 - 15 klik';
    },
  ),

  // Electric Grinders
  GrinderModel(
    id: 'baratza_encore',
    name: 'Baratza Encore',
    isManual: false,
    getSetting: (microns) {
      if (microns < 500) return '5 - 9';
      if (microns < 700) return '10 - 14';
      if (microns < 1000) return '15 - 22';
      return '25 - 30';
    },
  ),
  GrinderModel(
    id: 'fellow_ode_gen2',
    name: 'Fellow Ode Gen 2',
    isManual: false,
    getSetting: (microns) {
      if (microns < 500) return '1 - 2 (Tidak untuk espresso)';
      if (microns < 700) return '3 - 4';
      if (microns < 1000) return '5 - 7';
      return '8 - 11';
    },
  ),
  GrinderModel(
    id: 'niche_zero',
    name: 'Niche Zero',
    isManual: false,
    getSetting: (microns) {
      if (microns < 500) return '10 - 20';
      if (microns < 700) return '30 - 40';
      if (microns < 1000) return '45 - 60';
      return 'Over 60';
    },
  ),
  GrinderModel(
    id: 'eureka_mignon',
    name: 'Eureka Mignon (Filtro/Crono)',
    isManual: false,
    getSetting: (microns) {
      if (microns < 500) return '1 - 2 putaran penuh';
      if (microns < 700) return '2 - 3 putaran penuh';
      if (microns < 1000) return '3 - 4 putaran penuh';
      return '4 - 5 putaran penuh';
    },
  ),
  GrinderModel(
    id: 'df64',
    name: 'Turin DF64',
    isManual: false,
    getSetting: (microns) {
      if (microns < 500) return '10 - 20 angka';
      if (microns < 700) return '35 - 50 angka';
      if (microns < 1000) return '55 - 75 angka';
      return '80+ angka';
    },
  ),
  GrinderModel(
    id: 'wilfa_svart',
    name: 'Wilfa Svart',
    isManual: false,
    getSetting: (microns) {
      if (microns < 500) return 'Moka / Aeropress';
      if (microns < 700) return 'Filter (Halus)';
      if (microns < 1000) return 'Filter (Kasar)';
      return 'Steep / French Press';
    },
  ),
  GrinderModel(
    id: 'baratza_sette',
    name: 'Baratza Sette 270',
    isManual: false,
    getSetting: (microns) {
      if (microns < 500) return '5E - 9E';
      if (microns < 700) return '15 - 20 (Kurang optimal)';
      if (microns < 1000) return '25 - 31';
      return 'Tidak disarankan';
    },
  ),
  GrinderModel(
    id: 'breville_sgp',
    name: 'Breville Smart Grinder Pro',
    isManual: false,
    getSetting: (microns) {
      if (microns < 500) return '10 - 25';
      if (microns < 700) return '30 - 45';
      if (microns < 1000) return '50 - 55';
      return '60';
    },
  ),
  GrinderModel(
    id: 'lagom_p64',
    name: 'Option-O Lagom P64',
    isManual: false,
    getSetting: (microns) {
      if (microns < 500) return '0.5 - 1.5 angka';
      if (microns < 700) return '2 - 3 angka';
      if (microns < 1000) return '4 - 6 angka';
      return '7 - 9 angka';
    },
  ),
  GrinderModel(
    id: 'mahlkonig_ek43',
    name: 'Mahlkönig EK43',
    isManual: false,
    getSetting: (microns) {
      if (microns < 500) return '2 - 4';
      if (microns < 700) return '5 - 8';
      if (microns < 1000) return '9 - 12';
      return '13 - 16';
    },
  ),
];

String getGrindCategoryName(int microns, String lang) {
  if (microns <= 400) return AppStrings.str(lang, 'custom_grind_400');
  if (microns <= 600) return AppStrings.str(lang, 'custom_grind_600');
  if (microns <= 800) return AppStrings.str(lang, 'custom_grind_800');
  if (microns <= 1000) return AppStrings.str(lang, 'custom_grind_1000');
  if (microns <= 1200) return AppStrings.str(lang, 'custom_grind_1200');
  return AppStrings.str(lang, 'custom_grind_1400');
}
